public class Student
{
    private int roll;
    private String name;
    private int fees;
    //Constructor
    public Student(int roll, String name, int fees){this.roll = roll;this.name = name;this.fees = fees;}
    //Getters
    public int getRoll(){return roll;}
    public String getName(){return name;}
    public int getFees(){return fees;}
    //Setters
    public void setRoll(int roll){this.roll = roll;}
    public void setName(String name){this.name = name;}
    public void setFees(int fees){this.fees = fees;}
}
