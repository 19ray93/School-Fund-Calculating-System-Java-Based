import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class School{
    public static void main(String[] args){
        List<Student> students = new ArrayList<Student>();
        List<Teacher> teachers = new ArrayList<Teacher>();
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter No of Students in the School");
        int x = sc.nextInt();
        System.out.println("Enter No of Teachers in the School");
        int y = sc.nextInt();
        System.out.println("Enter Students Detail");
        for(int i = 0; i<x; i++){
            System.out.println("Enter Student Roll");
            int myId = sc.nextInt();
            sc.nextLine();
            System.out.println("Enter Student Name");
            String myName = sc.nextLine();
            System.out.println("Enter Fees to be Paid");
            int myFees = sc.nextInt();
            Student st = new Student(myId, myName, myFees);
            students.add(st);
        }
        System.out.println("Enter Teachers Detail");
        for(int i = 0; i<y; i++){
            System.out.println("Enter Teacher Id");
            int myId = sc.nextInt();
            sc.nextLine();
            System.out.println("Enter Teacher Name");
            String myName = sc.nextLine();
            System.out.println("Enter Salary to be Paid");
            int mySalary = sc.nextInt();
            Teacher tc = new Teacher(myId, myName, mySalary);
            teachers.add(tc);
        }
        int totalFeesPaid = 0;
        int totalSalaryPaid = 0;
        int totalStudents = students.size();
        int totalTeachers = teachers.size();
        int totalSchoolBalance;
        for(int i = 0; i<totalStudents; i++)
        totalFeesPaid += students.get(i).getFees();
        for(int i = 0; i<totalTeachers; i++)
        totalSalaryPaid += teachers.get(i).getSalary();
        totalSchoolBalance = totalFeesPaid - totalSalaryPaid;
        if(totalSchoolBalance>0)
        System.out.println("Current Balance of School Fund is = " + totalSchoolBalance);
        else
        System.out.println("School is Running Out of Fund, Increase Fees or Give Less Salary Please");
    }
}
